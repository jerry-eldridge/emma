var plot_8cpp =
[
    [ "GraphPaper", "plot_8cpp.html#ac015766db7d2fc6bd12966c73c71fbcb", null ],
    [ "GraphPolygon", "plot_8cpp.html#ae4572006c82a2c1eed42c7c845e41956", null ],
    [ "GraphPolygon2", "plot_8cpp.html#a896b061d8c5334d1db327ca0b1f49b71", null ],
    [ "Plot", "plot_8cpp.html#ae2a051ac8a896f0274ac928c429bef73", null ]
];