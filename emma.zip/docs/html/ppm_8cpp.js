var ppm_8cpp =
[
    [ "PGM_P2_From_Image", "ppm_8cpp.html#a1561f4b24aaceedabe389397068f2a2e", null ],
    [ "PGM_P5_From_Image", "ppm_8cpp.html#a83476112cd14cea1a46711f429371603", null ],
    [ "PPM_P6_From_ColorImage", "ppm_8cpp.html#a194be32f44473b54e70a66e6f70be142", null ],
    [ "Read_PGM_File", "ppm_8cpp.html#a49481275f378b7c488c573c8e6ef6873", null ],
    [ "Read_PGM_Header", "ppm_8cpp.html#a085da9e334ebfb46e6f827ea950e6352", null ],
    [ "Read_PGM_P2_File_Helper", "ppm_8cpp.html#a4351c29e118e4c71deeb12bdb666d33b", null ],
    [ "Read_PGM_P5_File_Helper", "ppm_8cpp.html#a9092e4ddc0e41f1b63e663e10df83553", null ],
    [ "Read_PPM_File", "ppm_8cpp.html#a43c3f07d2f4769ef69305ce8d6cc0e05", null ],
    [ "Read_PPM_Header", "ppm_8cpp.html#ab3c4dba97b14baa168e46e711aeb95bb", null ],
    [ "Read_PPM_P6_File_Helper", "ppm_8cpp.html#ab9c6ebd6dce0a557006b4ab429458ce3", null ]
];