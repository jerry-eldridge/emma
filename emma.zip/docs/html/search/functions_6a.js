var searchData=
[
  ['jpg_5ffrom_5fcolorimage',['JPG_From_ColorImage',['../jpg_8cpp.html#a015916cafadc1e069b7eb5f3ea6016d9',1,'jpg.cpp']]],
  ['jpg_5ffrom_5fimage',['JPG_From_Image',['../jpg_8cpp.html#a3a9d23ac6ff7f3032f9532aa8e5de8fc',1,'jpg.cpp']]]
];
