var searchData=
[
  ['edge_2ecpp',['edge.cpp',['../edge_8cpp.html',1,'']]],
  ['edgeslaplaciandoublearray',['EdgesLaplacianDoubleArray',['../doublearray_8cpp.html#ae4e3b80458efff3f8e6756b8b9cc27a3',1,'doublearray.cpp']]],
  ['edgessobeldoublearray',['EdgesSobelDoubleArray',['../doublearray_8cpp.html#af3f1295a7e4a75c43907db64e40c2400',1,'doublearray.cpp']]],
  ['ellipse',['Ellipse',['../ellipse_8cpp.html#ae494b0e4133b1b8b4eaf339383479221',1,'ellipse.cpp']]],
  ['ellipse_2ecpp',['ellipse.cpp',['../ellipse_8cpp.html',1,'']]],
  ['ema_2dfmt_2ecpp',['ema-fmt.cpp',['../ema-fmt_8cpp.html',1,'']]],
  ['erodedoublearray',['ErodeDoubleArray',['../doublearray_8cpp.html#ac025547a3c77be19835c883ce233d902',1,'doublearray.cpp']]],
  ['erodedoublearray2',['ErodeDoubleArray2',['../doublearray_8cpp.html#a05656fb702a00b8149dfa78bfae2582c',1,'doublearray.cpp']]],
  ['extenddoublearray',['ExtendDoubleArray',['../doublearray_8cpp.html#a0901a62db5e9b8f00bb8d74b2f663061',1,'doublearray.cpp']]]
];
