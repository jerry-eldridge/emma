var searchData=
[
  ['centerdoublearray',['CenterDoubleArray',['../doublearray_8cpp.html#aa26e1056a74ba31a3081a7b63a72ae0f',1,'doublearray.cpp']]],
  ['clipdoublearrayusingzscore',['ClipDoubleArrayUsingZScore',['../doublearray_8cpp.html#a68d66dd58f1de9c0778ff6f80ab10dea',1,'doublearray.cpp']]],
  ['closedoublearray',['CloseDoubleArray',['../doublearray_8cpp.html#a05c67876c6eb936bce9e5d33ca8401ca',1,'doublearray.cpp']]],
  ['closedoublearray2',['CloseDoubleArray2',['../doublearray_8cpp.html#a94a0f3e08aecc9874677682fd5c982d2',1,'doublearray.cpp']]],
  ['compare',['compare',['../ema-fmt_8cpp.html#a20725ac53f6720e2d8861abfc1dde5c9',1,'ema-fmt.cpp']]],
  ['concattwoimagesbywidth',['ConcatTwoImagesByWidth',['../int__images_8cpp.html#aba51d8e304322c1c4ae2283aca9ea218',1,'int_images.cpp']]],
  ['convolvedoublearrays',['ConvolveDoubleArrays',['../doublearray_8cpp.html#a52a21b223027d4451e19d0ba82ee7824',1,'doublearray.cpp']]],
  ['convolveintarrays',['ConvolveIntArrays',['../int__images_8cpp.html#a78fd5c1f36ae8a7e7371412aef1ec4e0',1,'int_images.cpp']]],
  ['copydoubletodoublearray',['CopyDoubleToDoubleArray',['../doublearray_8cpp.html#af5ae02f38013ee530b629f5e2cbb4093',1,'doublearray.cpp']]],
  ['copydoubletointarray',['CopyDoubleToIntArray',['../int__images_8cpp.html#a3cc4ac0921702a9e1444dec0b1ac6c67',1,'int_images.cpp']]],
  ['copyinttodoublearray',['CopyIntToDoubleArray',['../int__images_8cpp.html#a52256a9a6fe5c6129391f2314bedf948',1,'int_images.cpp']]],
  ['correctsignedbyteimage',['CorrectSignedByteImage',['../usr__misc_8cpp.html#abd9af5ff430750a645fffb17208a8733',1,'usr_misc.cpp']]],
  ['correctsignedwordimage',['CorrectSignedWordImage',['../int__images_8cpp.html#a4bd82ce1c04b38108353551c51211a00',1,'int_images.cpp']]]
];
