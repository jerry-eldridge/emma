var searchData=
[
  ['paintbynumbersdoublearray',['PaintByNumbersDoubleArray',['../doublearray_8cpp.html#a0fe1cc9dcb110c5e9936c113d23a5ee0',1,'doublearray.cpp']]],
  ['pastedoublearray',['PasteDoubleArray',['../doublearray_8cpp.html#abff31a105bf6a91afd998deacdbf4d44',1,'doublearray.cpp']]],
  ['pastewithmaskdoublearray',['PasteWithMaskDoubleArray',['../doublearray_8cpp.html#ae050ddd846c56f992b5c5175ed449ad8',1,'doublearray.cpp']]],
  ['pgm_5fp2_5ffrom_5fimage',['PGM_P2_From_Image',['../ppm_8cpp.html#a1561f4b24aaceedabe389397068f2a2e',1,'ppm.cpp']]],
  ['pgm_5fp5_5ffrom_5fimage',['PGM_P5_From_Image',['../ppm_8cpp.html#a83476112cd14cea1a46711f429371603',1,'ppm.cpp']]],
  ['plot',['Plot',['../plot_8cpp.html#ae2a051ac8a896f0274ac928c429bef73',1,'Plot(char *data_file, int *img, int w, int h, int maxval, int x0, int y0, int x1, int y1, bool plot_points, bool draw_lines, bool draw_bars):&#160;plot.cpp'],['../plot__io_8cpp.html#aa4ca193ee4bc111df0e42493522274da',1,'Plot(char *data_file, char *image_file, bool plot_points, bool draw_lines, bool draw_bars):&#160;plot_io.cpp']]],
  ['pointinpolygontest',['PointInPolygonTest',['../comp__geometry_8cpp.html#aac9e1c9ec2e6dd9d8ac0d147d72f2102',1,'PointInPolygonTest(point *p, int N, double x, double y):&#160;comp_geometry.cpp'],['../polygon_8cpp.html#a10d5ec59ad89effaa33ef1ae3aaf514b',1,'PointInPolygonTest(pointDouble *p, int N, double x, double y):&#160;polygon.cpp']]],
  ['polygonbounds',['PolygonBounds',['../paint_8cpp.html#abb3f588d240c300d2d049660e7064237',1,'paint.cpp']]],
  ['polygoncentroid',['PolygonCentroid',['../comp__geometry_8cpp.html#af347554b700856d257b5d3b6947778dd',1,'comp_geometry.cpp']]],
  ['polygondoublearray',['PolygonDoubleArray',['../doublearray_8cpp.html#aa1bd64811b94064d93db7b17b0b3daca',1,'doublearray.cpp']]],
  ['polygonfill',['PolygonFill',['../paint_8cpp.html#ad69b78615f1146a1e415419f68d21c4e',1,'paint.cpp']]],
  ['polygonfillmean',['PolygonFillMean',['../paint_8cpp.html#afdc958a7074406769b8fc3ccba93e9f6',1,'paint.cpp']]],
  ['polypolyintersect',['PolyPolyIntersect',['../comp__geometry_8cpp.html#a249e4aef00b1f29f718d33328e86edfb',1,'comp_geometry.cpp']]],
  ['ppm_5fp6_5ffrom_5fcolorimage',['PPM_P6_From_ColorImage',['../ppm_8cpp.html#a194be32f44473b54e70a66e6f70be142',1,'ppm.cpp']]],
  ['projection',['Projection',['../ema-fmt_8cpp.html#ac1d53d9bdaa9cd148e63ec89f5c5cfe0',1,'ema-fmt.cpp']]],
  ['putsymbol',['PutSymbol',['../font_8cpp.html#a2492fc8b784f947550b7cf0fda9f62cf',1,'font.cpp']]],
  ['putsymboltransform',['PutSymbolTransform',['../font_8cpp.html#a13f05cf4f10d9e9aa29bb3c41fc8fbbc',1,'font.cpp']]],
  ['puttext',['PutText',['../font_8cpp.html#a708194f6b8fd011ef16e6730546c5850',1,'font.cpp']]]
];
