var searchData=
[
  ['minimummaximumofarray',['MinimumMaximumOfArray',['../doublearray_8cpp.html#a05115ec8293000a3163007bcf88ee956',1,'doublearray.cpp']]],
  ['multiplydoublearrays',['MultiplyDoubleArrays',['../doublearray_8cpp.html#a086d2dccfe8cbef8a954881b6aae65c1',1,'doublearray.cpp']]],
  ['my_5fatan2',['My_atan2',['../usr__misc_8cpp.html#a99d386c61332efa7305d0ec6cbb818fe',1,'usr_misc.cpp']]]
];
