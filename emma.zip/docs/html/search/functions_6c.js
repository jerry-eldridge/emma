var searchData=
[
  ['locateminmaxdoublearray',['LocateMinMaxDoubleArray',['../doublearray_8cpp.html#a97bb928aff6f1afad8b0dfa3d703535e',1,'doublearray.cpp']]],
  ['logdoublearray',['LogDoubleArray',['../doublearray_8cpp.html#a6641c67e5167774ccfcd0beb47a4df1b',1,'doublearray.cpp']]]
];
