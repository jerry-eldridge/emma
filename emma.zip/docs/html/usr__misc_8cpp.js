var usr__misc_8cpp =
[
    [ "Array_Support", "usr__misc_8cpp.html#aa73bc4e41ee4072e934e2f4635d074f4", null ],
    [ "CorrectSignedByteImage", "usr__misc_8cpp.html#abd9af5ff430750a645fffb17208a8733", null ],
    [ "FalseColor", "usr__misc_8cpp.html#a1369905afee62639dc2ed307f2f41a1e", null ],
    [ "Fleck_L", "usr__misc_8cpp.html#a7d54bc171b23d92b6c7ea822c95667df", null ],
    [ "My_atan2", "usr__misc_8cpp.html#a99d386c61332efa7305d0ec6cbb818fe", null ],
    [ "round", "usr__misc_8cpp.html#a35abf8e6bc22bc3736fbd65416d8c3a2", null ],
    [ "StringToUppercase", "usr__misc_8cpp.html#a7a621f07d1f3d8efab05dbb3721d0184", null ],
    [ "swap", "usr__misc_8cpp.html#a489d747d9f8c2c44426a138df483d6b3", null ]
];