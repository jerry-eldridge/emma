var jpg_8cpp =
[
    [ "JPG_From_ColorImage", "jpg_8cpp.html#a015916cafadc1e069b7eb5f3ea6016d9", null ],
    [ "JPG_From_Image", "jpg_8cpp.html#a3a9d23ac6ff7f3032f9532aa8e5de8fc", null ],
    [ "Read_Color_JPG_File", "jpg_8cpp.html#a86aa5ad9e944bd2072135b36c8c2564a", null ],
    [ "Read_JPG_File", "jpg_8cpp.html#adf3f94106852bc5fc0806cdb76c01907", null ],
    [ "Save_JPG_P6", "jpg_8cpp.html#af458fb5800fd9b1740a7f8b7243d3fca", null ]
];