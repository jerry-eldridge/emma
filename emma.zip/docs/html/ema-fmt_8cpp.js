var ema_fmt_8cpp =
[
    [ "BackFaceTest", "ema-fmt_8cpp.html#aa0f292641e20d262acae6cd3bf4dc26d", null ],
    [ "bubblesort", "ema-fmt_8cpp.html#a8fdeaf22db4641c22cc3711035267392", null ],
    [ "compare", "ema-fmt_8cpp.html#a20725ac53f6720e2d8861abfc1dde5c9", null ],
    [ "Projection", "ema-fmt_8cpp.html#ac1d53d9bdaa9cd148e63ec89f5c5cfe0", null ],
    [ "Read_Em2_File", "ema-fmt_8cpp.html#a1e1b8e60938ac30930d080833004acf1", null ],
    [ "Read_Ema_File", "ema-fmt_8cpp.html#aa9ffd74e448df044ddd3c15b202cb9df", null ]
];